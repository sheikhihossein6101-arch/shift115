package com.example.shiftyar115

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** نگهداری داده‌ها در SharedPreferences (سازگار با نسخه‌های قبل) + پشتیبان‌گیری JSON. */
class ShiftStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("shift_yar_data", Context.MODE_PRIVATE)

    val personnel = mutableStateListOf<String>()
    val shifts = mutableStateListOf<ShiftEntry>()
    val substitutions = mutableStateListOf<Substitution>()
    var baseName by mutableStateOf("")
        private set
    var unavailableRules by mutableStateOf("")
        private set
    var requiredRules by mutableStateOf("")
        private set
    var productivityBase by mutableStateOf(false)
        private set
    var restSlots by mutableStateOf(2)
        private set
    var holidayRules by mutableStateOf("")
        private set

    init {
        load()
    }

    private fun load() {
        personnel.clear()
        shifts.clear()
        substitutions.clear()
        try {
            val a = JSONArray(prefs.getString("substitutions", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                substitutions.add(
                    Substitution(
                        o.optString("date"), o.optString("substitute"),
                        o.optString("original"), o.optDouble("hours", 0.0)
                    )
                )
            }
        } catch (_: Exception) {
        }
        try {
            val a = JSONArray(prefs.getString("personnel", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val s = a.optString(i)
                if (s.isNotBlank()) personnel.add(s)
            }
        } catch (_: Exception) {
        }
        try {
            val a = JSONArray(prefs.getString("shifts", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                shifts.add(
                    ShiftEntry(
                        o.optString("date"), o.optString("type"),
                        o.optString("first"), o.optString("second")
                    )
                )
            }
        } catch (_: Exception) {
        }
        baseName = prefs.getString("base_name", "") ?: ""
        unavailableRules = prefs.getString("unavailable_rules", "") ?: ""
        requiredRules = prefs.getString("required_rules", "") ?: ""
        productivityBase = prefs.getBoolean("productivity_base", false)
        restSlots = prefs.getInt("rest_slots", 2)
        holidayRules = prefs.getString("holiday_rules", "") ?: ""
    }

    private fun savePersonnel() {
        val a = JSONArray()
        personnel.forEach { a.put(it) }
        prefs.edit().putString("personnel", a.toString()).apply()
    }

    fun saveShifts() {
        prefs.edit().putString("shifts", shiftsToJson().toString()).apply()
    }

    private fun shiftsToJson(): JSONArray {
        val a = JSONArray()
        shifts.forEach {
            a.put(
                JSONObject()
                    .put("date", it.date).put("type", it.type)
                    .put("first", it.first).put("second", it.second)
            )
        }
        return a
    }

    private fun substitutionsToJson(): JSONArray {
        val a = JSONArray()
        substitutions.forEach {
            a.put(
                JSONObject()
                    .put("date", it.date).put("substitute", it.substitute)
                    .put("original", it.original).put("hours", it.hours)
            )
        }
        return a
    }

    fun saveSubstitutions() {
        prefs.edit().putString("substitutions", substitutionsToJson().toString()).apply()
    }

    fun addSubstitution(s: Substitution) {
        substitutions.add(s)
        saveSubstitutions()
    }

    fun removeSubstitution(s: Substitution) {
        substitutions.remove(s)
        saveSubstitutions()
    }

    private fun holidayKey(year: Int, month: Int) = String.format(java.util.Locale.US, "%04d/%02d", year, month)

    /** روزهای تعطیلِ علامت‌خورده‌ی دستی (مثلاً تعطیلات قمری) برای یک ماه. */
    fun extraHolidays(year: Int, month: Int): Set<Int> =
        Rules.parse(holidayRules)[holidayKey(year, month)] ?: emptySet()

    fun toggleHoliday(year: Int, month: Int, day: Int) {
        val cur = extraHolidays(year, month)
        val next = if (day in cur) cur - day else cur + day
        holidayRules = Rules.upsert(holidayRules, holidayKey(year, month), next)
        prefs.edit().putString("holiday_rules", holidayRules).apply()
    }

    fun updateBaseName(value: String) {
        baseName = value
        prefs.edit().putString("base_name", value).apply()
    }

    fun setProductivity(value: Boolean) {
        productivityBase = value
        prefs.edit().putBoolean("productivity_base", value).apply()
    }

    fun setRest(value: Int) {
        restSlots = value
        prefs.edit().putInt("rest_slots", value).apply()
    }

    fun setUnavailable(value: String) {
        unavailableRules = value
        prefs.edit().putString("unavailable_rules", value).apply()
    }

    fun setRequired(value: String) {
        requiredRules = value
        prefs.edit().putString("required_rules", value).apply()
    }

    /** null یعنی موفق؛ در غیر این صورت پیام خطا. */
    fun addPerson(raw: String): String? {
        val name = raw.replace(":", "").trim()
        if (name.isBlank()) return "نام پرسنل را وارد کنید"
        if (personnel.any { it.equals(name, ignoreCase = true) }) return "این نام قبلاً ثبت شده است"
        personnel.add(name)
        savePersonnel()
        return null
    }

    fun removePerson(name: String) {
        personnel.remove(name)
        savePersonnel()
        setUnavailable(Rules.remove(unavailableRules, name))
        setRequired(Rules.remove(requiredRules, name))
    }

    fun monthEntries(year: Int, month: Int): List<ShiftEntry> =
        shifts.filter { it.isIn(year, month) }

    fun replaceMonth(year: Int, month: Int, entries: List<ShiftEntry>) {
        shifts.removeAll { it.isIn(year, month) }
        shifts.addAll(entries)
        saveShifts()
    }

    fun exportJson(): String {
        val o = JSONObject()
        o.put("app", "shiftyar115")
        o.put("version", 1)
        o.put("base_name", baseName)
        o.put("productivity_base", productivityBase)
        o.put("rest_slots", restSlots)
        o.put("unavailable_rules", unavailableRules)
        o.put("required_rules", requiredRules)
        val p = JSONArray()
        personnel.forEach { p.put(it) }
        o.put("personnel", p)
        o.put("shifts", shiftsToJson())
        o.put("substitutions", substitutionsToJson())
        o.put("holiday_rules", holidayRules)
        return o.toString(2)
    }

    /** null یعنی موفق؛ در غیر این صورت پیام خطا و هیچ چیزی تغییر نمی‌کند. */
    fun importJson(raw: String): String? {
        val o = try {
            JSONObject(raw)
        } catch (_: Exception) {
            return "فایل پشتیبان معتبر نیست"
        }
        if (o.optString("app") != "shiftyar115") return "این فایل پشتیبان شیفت‌یار نیست"
        val newPeople = ArrayList<String>()
        val newShifts = ArrayList<ShiftEntry>()
        val newSubs = ArrayList<Substitution>()
        try {
            val sa = o.optJSONArray("substitutions") ?: JSONArray()
            for (i in 0 until sa.length()) {
                val so = sa.optJSONObject(i) ?: continue
                newSubs.add(
                    Substitution(
                        so.optString("date"), so.optString("substitute"),
                        so.optString("original"), so.optDouble("hours", 0.0)
                    )
                )
            }
            val p = o.optJSONArray("personnel") ?: JSONArray()
            for (i in 0 until p.length()) {
                val s = p.optString(i)
                if (s.isNotBlank()) newPeople.add(s)
            }
            val a = o.optJSONArray("shifts") ?: JSONArray()
            for (i in 0 until a.length()) {
                val s = a.optJSONObject(i) ?: continue
                newShifts.add(
                    ShiftEntry(
                        s.optString("date"), s.optString("type"),
                        s.optString("first"), s.optString("second")
                    )
                )
            }
        } catch (_: Exception) {
            return "محتوای فایل پشتیبان خراب است"
        }
        personnel.clear()
        personnel.addAll(newPeople)
        shifts.clear()
        shifts.addAll(newShifts)
        substitutions.clear()
        substitutions.addAll(newSubs)
        saveSubstitutions()
        holidayRules = o.optString("holiday_rules")
        prefs.edit().putString("holiday_rules", holidayRules).apply()
        savePersonnel()
        saveShifts()
        updateBaseName(o.optString("base_name"))
        setProductivity(o.optBoolean("productivity_base", false))
        setRest(o.optInt("rest_slots", 2))
        setUnavailable(o.optString("unavailable_rules"))
        setRequired(o.optString("required_rules"))
        return null
    }
}
