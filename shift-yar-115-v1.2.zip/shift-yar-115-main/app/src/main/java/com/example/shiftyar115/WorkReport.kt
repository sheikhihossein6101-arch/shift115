package com.example.shiftyar115

import java.util.Locale

/** جایگزینی: [substitute] به‌جای [original] به‌مدت [hours] ساعت کار کرده است. */
data class Substitution(
    val date: String,
    val substitute: String,
    val original: String,
    val hours: Double
)

fun Substitution.parts(): IntArray? {
    val p = date.enDigits().split("/")
    if (p.size != 3) return null
    val y = p[0].toIntOrNull()
    val m = p[1].toIntOrNull()
    val d = p[2].toIntOrNull()
    return if (y == null || m == null || d == null) null else intArrayOf(y, m, d)
}

fun Substitution.isIn(year: Int, month: Int): Boolean {
    val p = parts() ?: return false
    return p[0] == year && p[1] == month
}

fun Substitution.day(): Int = parts()?.get(2) ?: 0

data class PersonWork(
    val name: String,
    val morningNormal: Int,
    val morningHoliday: Int,
    val nightNormal: Int,
    val nightHoliday: Int,
    val full24Normal: Int,
    val full24Holiday: Int,
    val scheduledHours: Double,
    val coveredForOthers: Double,
    val coveredByOthers: Double
) {
    /** کارکرد خالص = ساعت برنامه + ساعت جایگزینی برای دیگران − ساعتی که دیگران جای او بودند */
    val netHours: Double
        get() = (scheduledHours + coveredForOthers - coveredByOthers).coerceAtLeast(0.0)

    val totalShifts: Int
        get() = morningNormal + morningHoliday + nightNormal + nightHoliday + full24Normal + full24Holiday
}

object WorkReport {
    const val MORNING_HOURS = 12.0
    const val NIGHT_HOURS = 12.0
    const val FULL_HOURS = 24.0

    /** تعطیلات رسمی ثابت شمسی. تعطیلات قمری هر سال عوض می‌شود و دستی علامت زده می‌شود. */
    fun isFixedHoliday(month: Int, day: Int): Boolean = when (month) {
        1 -> day in 1..4 || day == 12 || day == 13
        3 -> day == 14 || day == 15
        11 -> day == 22
        12 -> day == 29
        else -> false
    }

    fun autoHolidays(year: Int, month: Int): Set<Int> {
        val len = Jalali.monthLength(year, month)
        return (1..len).filter { d ->
            Jalali.weekdayIndex(year, month, d) == 6 || isFixedHoliday(month, d)
        }.toSet()
    }

    fun holidays(year: Int, month: Int, extra: Set<Int>): Set<Int> =
        autoHolidays(year, month) + extra.filter { it in 1..Jalali.monthLength(year, month) }

    fun shiftHours(type: String): Double = when (type) {
        TYPE_MORNING -> MORNING_HOURS
        TYPE_NIGHT -> NIGHT_HOURS
        else -> FULL_HOURS
    }

    /** تعطیل بودن شیفت بر اساس تاریخ شروع شیفت سنجیده می‌شود. */
    fun build(
        people: List<String>,
        shifts: List<ShiftEntry>,
        subs: List<Substitution>,
        year: Int,
        month: Int,
        holidays: Set<Int>
    ): List<PersonWork> {
        val monthShifts = shifts.filter { it.isIn(year, month) }
        val monthSubs = subs.filter { it.isIn(year, month) }
        val names = LinkedHashSet<String>()
        names.addAll(people)
        for (e in monthShifts) {
            if (e.first.isNotBlank()) names.add(e.first)
            if (e.second.isNotBlank()) names.add(e.second)
        }
        for (s in monthSubs) {
            names.add(s.substitute)
            names.add(s.original)
        }

        val result = ArrayList<PersonWork>()
        for (name in names) {
            var mN = 0
            var mH = 0
            var nN = 0
            var nH = 0
            var fN = 0
            var fH = 0
            var hours = 0.0
            for (e in monthShifts) {
                if (e.first != name && e.second != name) continue
                val hol = e.day() in holidays
                when (e.type) {
                    TYPE_MORNING -> if (hol) mH++ else mN++
                    TYPE_NIGHT -> if (hol) nH++ else nN++
                    else -> if (hol) fH++ else fN++
                }
                hours += shiftHours(e.type)
            }
            var forOthers = 0.0
            var byOthers = 0.0
            for (s in monthSubs) {
                if (s.substitute == name) forOthers += s.hours
                if (s.original == name) byOthers += s.hours
            }
            result.add(PersonWork(name, mN, mH, nN, nH, fN, fH, hours, forOthers, byOthers))
        }
        return result
    }
}

fun Double.faHours(): String =
    if (this % 1.0 == 0.0) toInt().fa()
    else String.format(Locale.US, "%.1f", this).replace(".", "٫").faDigits()
