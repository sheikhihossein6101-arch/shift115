package com.example.shiftyar115

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (_: Exception) {
        context.toast("امکان باز کردن لینک وجود ندارد", true)
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, color = Navy) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
fun ContactDialog(context: Context, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تماس با ما", color = Navy, fontWeight = FontWeight.Bold)
                Text(
                    "پیشنهادها و پرسش‌های شما به بهتر شدن شیفت‌یار کمک می‌کند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted
                )
            }
        },
        text = {
            Card(colors = CardDefaults.cardColors(containerColor = PaleBlue), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("حسین شیخی", fontWeight = FontWeight.Bold, color = Navy)
                    Text("کارشناس ارشد پرستاری اورژانس", style = MaterialTheme.typography.bodyMedium)
                    Text("سمنان  •  پشتیبانی شیفت‌یار", style = MaterialTheme.typography.bodySmall, color = Muted)
                    TextButton(onClick = { openUrl(context, "https://www.iranianems.ir") }) {
                        Text("وب‌سایت: www.iranianems.ir", color = Blue)
                    }
                    TextButton(onClick = { openUrl(context, "https://eitaa.com/iranianems") }) {
                        Text("ایتا: eitaa.com/iranianems", color = Blue)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}

@Composable
fun BackupDialog(onExport: () -> Unit, onImport: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("پشتیبان‌گیری و بازیابی", fontWeight = FontWeight.Bold, color = Navy) },
        text = {
            Text(
                "اطلاعات (پرسنل، برنامه‌ها و قوانین) فقط روی همین گوشی ذخیره می‌شوند. " +
                    "با گرفتن فایل پشتیبان می‌توانید آن‌ها را به گوشی دیگر منتقل کنید یا بعد از حذف برنامه برگردانید."
            )
        },
        confirmButton = { TextButton(onClick = onExport) { Text("ذخیره فایل پشتیبان") } },
        dismissButton = {
            Row {
                TextButton(onClick = onImport) { Text("بازیابی از فایل") }
                TextButton(onClick = onDismiss) { Text("بستن") }
            }
        }
    )
}

@Composable
fun SchedulePreviewDialog(
    result: ScheduleResult,
    existingCount: Int,
    onSave: () -> Unit,
    onRegenerate: () -> Unit,
    onDismiss: () -> Unit
) {
    val maxCount = (result.counts.values.maxOrNull() ?: 1).coerceAtLeast(1)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("پیش‌نمایش برنامه", fontWeight = FontWeight.Bold, color = Navy) },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 440.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "${result.entries.size.fa()} شیفت ساخته شد." +
                        if (existingCount > 0) " برنامه فعلی این ماه (${existingCount.fa()} شیفت) جایگزین می‌شود." else "",
                    style = MaterialTheme.typography.bodyMedium
                )
                if (result.warnings.isNotEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4E0)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFB26A00), modifier = Modifier.size(18.dp))
                                Text("نکات قابل توجه", fontWeight = FontWeight.Bold, color = Color(0xFFB26A00))
                            }
                            result.warnings.take(8).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                            if (result.warnings.size > 8) {
                                Text("و ${(result.warnings.size - 8).fa()} مورد دیگر…", style = MaterialTheme.typography.bodySmall, color = Muted)
                            }
                        }
                    }
                }
                Text("تعداد شیفت هر نفر", fontWeight = FontWeight.Bold, color = Navy)
                result.counts.entries.sortedByDescending { it.value }.forEach { (name, c) ->
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(name, style = MaterialTheme.typography.bodyMedium)
                            Text(c.fa(), fontWeight = FontWeight.Bold, color = Blue)
                        }
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(PaleBlue)
                        ) {
                            Box(
                                Modifier
                                    .fillMaxWidth(c.toFloat() / maxCount)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Teal)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onSave) { Text("ذخیره برنامه", fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                TextButton(onClick = onRegenerate) { Text("پیشنهاد دیگر") }
                TextButton(onClick = onDismiss) { Text("انصراف") }
            }
        }
    )
}
