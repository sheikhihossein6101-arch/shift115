package com.example.shiftyar115

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportScreen(store: ShiftStore, context: Context) {
    val today = remember { Jalali.today() }
    var year by rememberSaveable { mutableStateOf(today[0]) }
    var month by rememberSaveable { mutableStateOf(today[1]) }
    var subDay by rememberSaveable { mutableStateOf("") }
    var subWho by rememberSaveable { mutableStateOf("") }
    var subFor by rememberSaveable { mutableStateOf("") }
    var subHours by rememberSaveable { mutableStateOf("") }

    val monthDays = Jalali.monthLength(year, month)
    val auto = WorkReport.autoHolidays(year, month)
    val extra = store.extraHolidays(year, month)
    val holidays = WorkReport.holidays(year, month, extra)
    val monthShifts = store.monthEntries(year, month)
    val has12 = monthShifts.any { it.type != TYPE_24 }
    val has24 = monthShifts.any { it.type == TYPE_24 }
    val rows = WorkReport.build(
        store.personnel.toList(), store.shifts.toList(), store.substitutions.toList(), year, month, holidays
    )
    val monthSubs = store.substitutions.filter { it.isIn(year, month) }.sortedBy { it.day() }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionCard("ماه گزارش", icon = Icons.Default.DateRange) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { if (month == 1) { month = 12; year -= 1 } else month -= 1 }) {
                    Icon(Icons.Default.KeyboardArrowRight, contentDescription = "ماه قبل", tint = Navy)
                }
                Text(
                    Jalali.monthTitle(year, month),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Navy
                )
                IconButton(onClick = { if (month == 12) { month = 1; year += 1 } else month += 1 }) {
                    Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "ماه بعد", tint = Navy)
                }
            }
            Text(
                "روزهای تعطیل این ماه: " + holidays.sorted().joinToString("، ") { it.fa() },
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
        }

        // ───────── کارکرد هر نفر
        Text("کارکرد افراد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Navy)
        if (rows.isEmpty()) {
            EmptyState(Icons.Default.List, "هنوز کسی ثبت نشده", "ابتدا پرسنل و شیفت‌های ماه را ثبت کنید.")
        }
        rows.forEach { r ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Avatar(r.name)
                        Text(r.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Navy)
                        Column(horizontalAlignment = Alignment.End) {
                            Text(r.netHours.faHours(), fontWeight = FontWeight.Bold, color = Teal, style = MaterialTheme.typography.titleLarge)
                            Text("ساعت کارکرد", style = MaterialTheme.typography.labelSmall, color = Muted)
                        }
                    }
                    val chips = ArrayList<Triple<String, String, Color>>()
                    if (has12) {
                        chips.add(Triple("صبح عادی", r.morningNormal.fa(), Navy))
                        chips.add(Triple("صبح تعطیل", r.morningHoliday.fa(), Danger))
                        chips.add(Triple("شب عادی", r.nightNormal.fa(), Blue))
                        chips.add(Triple("شب تعطیل", r.nightHoliday.fa(), Danger))
                    }
                    if (has24) {
                        chips.add(Triple("۲۴ ساعته عادی", r.full24Normal.fa(), Navy))
                        chips.add(Triple("۲۴ ساعته تعطیل", r.full24Holiday.fa(), Danger))
                    }
                    chips.add(Triple("جایگزین دیگران (ساعت)", r.coveredForOthers.faHours(), Teal))
                    chips.add(Triple("جایگزین‌شده (ساعت)", r.coveredByOthers.faHours(), Color(0xFFEF6C00)))
                    chips.chunked(3).forEach { chunk ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            chunk.forEach { c -> StatChip(c.first, c.second, c.third, Modifier.weight(1f)) }
                            repeat(3 - chunk.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    Text(
                        "ساعت برنامه: ${r.scheduledHours.faHours()}  •  کارکرد = ساعت برنامه + جایگزینی برای دیگران − ساعتی که دیگران جای او بودند",
                        style = MaterialTheme.typography.bodySmall,
                        color = Muted
                    )
                }
            }
        }
        AppButton("خروجی PDF کارکرد ماه", icon = Icons.Default.Share, container = Teal) {
            exportWorkReportPdf(context, rows, store.substitutions.toList(), holidays, year, month, store.baseName, has12, has24)
        }

        // ───────── جایگزینی
        SectionCard("ثبت جایگزینی ساعتی", icon = Icons.Default.Person) {
            Text(
                "وقتی یک نفر چند ساعت جای همکارش آمده، اینجا ثبت کنید تا در کارکرد هر دو لحاظ شود.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
            OutlinedTextField(
                value = subDay,
                onValueChange = { subDay = it.filter(Char::isDigit).take(2) },
                label = { Text("روز ماه (۱ تا ${monthDays.fa()})") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            PersonDropdown("جایگزین (کسی که آمده)", store.personnel, subWho) { subWho = it }
            PersonDropdown("جای چه کسی", store.personnel, subFor) { subFor = it }
            OutlinedTextField(
                value = subHours,
                onValueChange = { subHours = it.filter { c -> c.isDigit() || c == '.' || c == '٫' }.take(5) },
                label = { Text("تعداد ساعت (مثلاً ۴ یا ۲.۵)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            AppButton("ثبت جایگزینی", icon = Icons.Default.Check, container = Blue) {
                val d = subDay.enDigits().toIntOrNull()
                val h = subHours.enDigits().replace('٫', '.').toDoubleOrNull()
                if (d == null || d !in 1..monthDays) {
                    context.toast("روز معتبر از ۱ تا ${monthDays.fa()} وارد کنید")
                } else if (subWho.isBlank() || subFor.isBlank()) {
                    context.toast("هر دو نفر را انتخاب کنید")
                } else if (subWho == subFor) {
                    context.toast("جایگزین و فرد اصلی باید متفاوت باشند")
                } else if (h == null || h <= 0.0 || h > 24.0) {
                    context.toast("ساعت باید بین ۰ و ۲۴ باشد")
                } else {
                    store.addSubstitution(Substitution(Jalali.key(year, month, d), subWho, subFor, h))
                    subDay = ""
                    subHours = ""
                    context.toast("جایگزینی ثبت شد")
                }
            }
            monthSubs.forEach { s ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PaleBlue).padding(start = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                        Text("${s.substitute} جای ${s.original}", fontWeight = FontWeight.Bold, color = Navy, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "روز ${s.day().fa()} ${Jalali.monthNames[month - 1]}  •  ${s.hours.faHours()} ساعت",
                            style = MaterialTheme.typography.bodySmall,
                            color = Muted
                        )
                    }
                    IconButton(onClick = { store.removeSubstitution(s) }) {
                        Icon(Icons.Default.Close, contentDescription = "حذف", tint = Danger)
                    }
                }
            }
        }

        // ───────── تعطیلات
        SectionCard("تعطیلات ماه", icon = Icons.Default.DateRange) {
            Text(
                "جمعه‌ها و تعطیلات رسمی ثابت (مثل نوروز و ۲۲ بهمن) خودکار قرمز می‌شوند. تعطیلات مناسبتی که هر سال تغییر می‌کنند، مثل تاسوعا و عاشورا، را خودتان با لمس روز علامت بزنید.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
            HolidayGrid(monthDays, auto, extra) { d -> store.toggleHoliday(year, month, d) }
        }
    }
}

@Composable
private fun StatChip(label: String, value: String, color: Color, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.10f)).padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(value, color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Text(label, color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun HolidayGrid(days: Int, auto: Set<Int>, extra: Set<Int>, onToggle: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        (1..days).toList().chunked(7).forEach { rowDays ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                rowDays.forEach { d ->
                    val locked = d in auto
                    val on = d in extra
                    val bg = when {
                        locked -> Danger.copy(alpha = 0.15f)
                        on -> Danger
                        else -> PaleBlue
                    }
                    val fg = when {
                        locked -> Danger
                        on -> Color.White
                        else -> Navy
                    }
                    Box(
                        Modifier
                            .weight(1f)
                            .heightIn(min = 38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(bg)
                            .clickable(enabled = !locked) { onToggle(d) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(d.fa(), color = fg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                repeat(7 - rowDays.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
