package com.example.shiftyar115

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(store: ShiftStore, context: Context, onNavigate: (Page) -> Unit) {
    val t = remember { Jalali.today() }
    val todayKey = Jalali.key(t[0], t[1], t[2])
    val todayShifts = store.shifts.filter { it.date.enDigits() == todayKey }
    val monthCount = store.monthEntries(t[0], t[1]).size
    val ruleCount = Rules.parse(store.unavailableRules).size + Rules.parse(store.requiredRules).size

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        HeroCard {
            Text("شیفت‌یار ۱۱۵", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                if (store.baseName.isBlank()) "مدیریت هوشمند شیفت‌های اورژانس ۱۱۵" else "پایگاه ${store.baseName}",
                color = Color(0xFFD8E8FA),
                style = MaterialTheme.typography.bodyMedium
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${Jalali.weekdayName(t[0], t[1], t[2])}  ${t[2].fa()} ${Jalali.monthNames[t[1] - 1]} ${t[0].fa()}",
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        SectionCard("شیفت امروز", icon = Icons.Default.DateRange) {
            if (todayShifts.isEmpty()) {
                EmptyState(
                    Icons.Default.List,
                    "برای امروز شیفتی ثبت نشده",
                    "از بخش «مدیریت شیفت‌ها» برنامه ماه را بسازید."
                )
            } else {
                todayShifts.forEach { e ->
                    Card(colors = CardDefaults.cardColors(containerColor = PaleBlue), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("شیفت ${e.type}", fontWeight = FontWeight.Bold, color = Navy)
                            listOf(e.first, e.second).filter { it.isNotBlank() }.forEach { n ->
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Avatar(n, 34.dp)
                                    Text(n, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("پرسنل", store.personnel.size.fa(), Icons.Default.Person, Blue, Modifier.weight(1f))
            StatTile("شیفت این ماه", monthCount.fa(), Icons.Default.DateRange, Teal, Modifier.weight(1f))
            StatTile("محدودیت‌ها", ruleCount.fa(), Icons.Default.Settings, Color(0xFFEF6C00), Modifier.weight(1f))
        }

        Text("دسترسی سریع", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Navy)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction("برنامه‌ریزی شیفت", "ساخت و ویرایش", Icons.Default.Edit, Modifier.weight(1f)) { onNavigate(Page.SHIFTS) }
            QuickAction("مدیریت پرسنل", "افزودن و حذف", Icons.Default.Person, Modifier.weight(1f)) { onNavigate(Page.PERSONNEL) }
        }
        QuickAction("کارکرد ماهانه", "شیفت شب، تعطیل و جایگزینی هر نفر", Icons.Default.List, Modifier.fillMaxWidth()) { onNavigate(Page.REPORT) }
        QuickAction("خروجی PDF ماه جاری", "چاپ یا اشتراک‌گذاری جدول شیفت‌ها", Icons.Default.Share, Modifier.fillMaxWidth()) {
            exportMonthlyPdf(context, store.shifts, t[0], t[1], store.baseName)
        }

        SectionCard("نام پایگاه", icon = Icons.Default.Settings) {
            OutlinedTextField(
                value = store.baseName,
                onValueChange = { store.updateBaseName(it) },
                label = { Text("نام پایگاه (روی PDF چاپ می‌شود)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
        }
    }
}

@Composable
private fun QuickAction(title: String, subtitle: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            IconBadge(icon)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = Navy, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
