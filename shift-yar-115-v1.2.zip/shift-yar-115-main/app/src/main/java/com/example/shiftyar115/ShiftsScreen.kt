package com.example.shiftyar115

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val RULE_ABSENT = "عدم حضور"
private const val RULE_REQUIRED = "حضور اجباری"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShiftsScreen(store: ShiftStore, context: Context) {
    val today = remember { Jalali.today() }
    var year by rememberSaveable { mutableStateOf(today[0]) }
    var month by rememberSaveable { mutableStateOf(today[1]) }
    var shiftType by rememberSaveable { mutableStateOf(TYPE_24) }
    var dayText by rememberSaveable { mutableStateOf("") }
    var firstPerson by rememberSaveable { mutableStateOf("") }
    var secondPerson by rememberSaveable { mutableStateOf("") }
    var editTarget by remember { mutableStateOf<ShiftEntry?>(null) }

    var rulePerson by rememberSaveable { mutableStateOf("") }
    var ruleType by rememberSaveable { mutableStateOf(RULE_ABSENT) }
    var ruleDays by remember { mutableStateOf(setOf<Int>()) }
    var ruleMenu by remember { mutableStateOf(false) }

    var preview by remember { mutableStateOf<ScheduleResult?>(null) }
    var calendarOpen by rememberSaveable { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<ShiftEntry?>(null) }

    val monthDays = Jalali.monthLength(year, month)
    val monthShifts = store.monthEntries(year, month).sortedWith(compareBy<ShiftEntry>({ it.day() }, { if (it.type == TYPE_NIGHT) 1 else 0 }))

    // اگر نوع شیفت دیگر مجاز نیست (خاموش شدن پایگاه بهره‌وری)
    LaunchedEffect(store.productivityBase) {
        if (!store.productivityBase) shiftType = TYPE_24
    }
    // بارگذاری روزهای ذخیره‌شده‌ی قانون برای فرد انتخاب‌شده
    LaunchedEffect(rulePerson, ruleType, store.unavailableRules, store.requiredRules) {
        val raw = if (ruleType == RULE_ABSENT) store.unavailableRules else store.requiredRules
        ruleDays = Rules.parse(raw).entries.firstOrNull { it.key.equals(rulePerson, true) }?.value ?: emptySet()
    }

    fun generate(seed: Long) {
        if (store.personnel.size < 2) {
            context.toast("ابتدا در بخش پرسنل حداقل دو نفر ثبت کنید", true)
            return
        }
        preview = ShiftScheduler.build(
            personnel = store.personnel.toList(),
            year = year,
            month = month,
            twoTypes = shiftType != TYPE_24,
            unavailableRaw = store.unavailableRules,
            requiredRaw = store.requiredRules,
            restSlots = store.restSlots,
            seed = seed
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // ───────── ماه و نوع شیفت
        SectionCard("ماه برنامه", icon = Icons.Default.DateRange) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (month == 1) { month = 12; year -= 1 } else month -= 1
                }) { Icon(Icons.Default.KeyboardArrowRight, contentDescription = "ماه قبل", tint = Navy) }
                Text(
                    Jalali.monthTitle(year, month),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Navy
                )
                IconButton(onClick = {
                    if (month == 12) { month = 1; year += 1 } else month += 1
                }) { Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "ماه بعد", tint = Navy) }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("پایگاه بهره‌وری", fontWeight = FontWeight.Medium, color = Navy)
                    Text("امکان شیفت ۱۲ ساعته (صبح و شب)", style = MaterialTheme.typography.bodySmall, color = Muted)
                }
                Switch(checked = store.productivityBase, onCheckedChange = { store.setProductivity(it) })
            }
            if (store.productivityBase) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(TYPE_24, TYPE_MORNING, TYPE_NIGHT).forEach { type ->
                        FilterChip(
                            selected = shiftType == type,
                            onClick = { shiftType = type },
                            label = { Text(if (type == TYPE_24) type else "شیفت $type") },
                            colors = pillChipColors()
                        )
                    }
                }
            }
        }

        // ───────── ساخت خودکار
        SectionCard("برنامه‌ریزی هوشمند", icon = Icons.Default.Refresh) {
            Text(
                "حالت ساخت: " + if (shiftType == TYPE_24) "۲۴ ساعته" else "۱۲ ساعته (صبح و شب)",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
            Text("استراحت بین شیفت‌ها", fontWeight = FontWeight.SemiBold, color = Navy)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 1, 2, 3).forEach { r ->
                    FilterChip(
                        selected = store.restSlots == r,
                        onClick = { store.setRest(r) },
                        label = { Text(if (r == 0) "بدون" else r.fa()) },
                        colors = pillChipColors()
                    )
                }
            }
            Text(
                "بعد از هر شیفت، فرد حداقل این تعداد شیفت استراحت می‌کند (در حالت ۲۴ ساعته یعنی همین تعداد روز).",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )

            Text("محدودیت فردی", fontWeight = FontWeight.SemiBold, color = Navy)
            Box {
                OutlinedButton(
                    onClick = { ruleMenu = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (rulePerson.isBlank()) "انتخاب از فهرست پرسنل" else rulePerson)
                }
                DropdownMenu(expanded = ruleMenu, onDismissRequest = { ruleMenu = false }) {
                    store.personnel.forEach { n ->
                        DropdownMenuItem(text = { Text(n) }, onClick = { rulePerson = n; ruleMenu = false })
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(RULE_ABSENT, RULE_REQUIRED).forEach { rt ->
                    FilterChip(
                        selected = ruleType == rt,
                        onClick = { ruleType = rt },
                        label = { Text(rt) },
                        colors = pillChipColors()
                    )
                }
            }
            DayGrid(
                days = monthDays,
                selected = ruleDays,
                onToggle = { d -> ruleDays = if (d in ruleDays) ruleDays - d else ruleDays + d }
            )
            AppButton("ذخیره محدودیت", icon = Icons.Default.Check, container = Blue) {
                if (rulePerson.isBlank()) {
                    context.toast("ابتدا نام پرسنل را انتخاب کنید")
                } else {
                    if (ruleType == RULE_ABSENT) {
                        store.setUnavailable(Rules.upsert(store.unavailableRules, rulePerson, ruleDays))
                    } else {
                        store.setRequired(Rules.upsert(store.requiredRules, rulePerson, ruleDays))
                    }
                    context.toast(if (ruleDays.isEmpty()) "محدودیت حذف شد" else "محدودیت ذخیره شد")
                }
            }

            val absent = Rules.parse(store.unavailableRules)
            val must = Rules.parse(store.requiredRules)
            if (absent.isNotEmpty() || must.isNotEmpty()) {
                Text("محدودیت‌های ثبت‌شده", fontWeight = FontWeight.SemiBold, color = Navy)
                absent.forEach { (n, ds) ->
                    RuleRow(n, RULE_ABSENT, ds, Danger) { store.setUnavailable(Rules.remove(store.unavailableRules, n)) }
                }
                must.forEach { (n, ds) ->
                    RuleRow(n, RULE_REQUIRED, ds, Teal) { store.setRequired(Rules.remove(store.requiredRules, n)) }
                }
            }

            AppButton("ساخت خودکار برنامه ماه", icon = Icons.Default.Refresh) {
                generate(System.nanoTime())
            }
        }

        // ───────── ثبت دستی
        SectionCard(if (editTarget != null) "ویرایش شیفت" else "ثبت دستی شیفت", icon = Icons.Default.Edit) {
            OutlinedTextField(
                value = dayText,
                onValueChange = { dayText = it.filter(Char::isDigit).take(2) },
                label = { Text("روز ماه (۱ تا ${monthDays.fa()})") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                supportingText = {
                    val d = dayText.enDigits().toIntOrNull()
                    if (d != null && d in 1..monthDays) {
                        Text("روز هفته: ${Jalali.weekdayName(year, month, d)}")
                    }
                }
            )
            PersonDropdown("نفر اول", store.personnel, firstPerson) { firstPerson = it }
            PersonDropdown("نفر دوم", store.personnel, secondPerson) { secondPerson = it }
            AppButton(if (editTarget != null) "ذخیره ویرایش" else "ثبت شیفت", icon = Icons.Default.Check) {
                val d = dayText.enDigits().toIntOrNull()
                if (d == null || d !in 1..monthDays) {
                    context.toast("روز معتبر از ۱ تا ${monthDays.fa()} وارد کنید")
                } else if (firstPerson.isBlank() || secondPerson.isBlank()) {
                    context.toast("هر دو نفر را انتخاب کنید")
                } else if (firstPerson == secondPerson) {
                    context.toast("دو نفر باید متفاوت باشند")
                } else {
                    val entry = ShiftEntry(Jalali.key(year, month, d), shiftType, firstPerson, secondPerson)
                    val editing = editTarget
                    val duplicate = store.shifts.any { it.date == entry.date && it.type == entry.type && it != editing }
                    if (duplicate) {
                        context.toast("برای این تاریخ و نوع شیفت قبلاً ثبت شده است")
                    } else {
                        if (editing != null) {
                            val idx = store.shifts.indexOf(editing)
                            if (idx >= 0) store.shifts[idx] = entry else store.shifts.add(entry)
                        } else {
                            store.shifts.add(entry)
                        }
                        store.saveShifts()
                        editTarget = null
                        firstPerson = ""
                        secondPerson = ""
                        dayText = ""
                        context.toast("شیفت ذخیره شد")
                    }
                }
            }
            if (editTarget != null) {
                OutlinedButton(
                    onClick = { editTarget = null; firstPerson = ""; secondPerson = ""; dayText = "" },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("انصراف از ویرایش") }
            }
        }

        // ───────── تقویم
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    Modifier.fillMaxWidth().clickable { calendarOpen = !calendarOpen },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IconBadge(Icons.Default.DateRange)
                    Text("تقویم ماهانه شیفت‌ها", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Navy)
                    Icon(if (calendarOpen) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, contentDescription = null, tint = Navy)
                }
                AnimatedVisibility(visible = calendarOpen) {
                    MonthlyShiftCalendar(year, month, monthShifts, today) { d -> dayText = d.fa() }
                }
            }
        }

        AppButton("خروجی PDF این ماه", icon = Icons.Default.Share, container = Teal) {
            exportMonthlyPdf(context, store.shifts, year, month, store.baseName)
        }

        // ───────── فهرست
        Text("شیفت‌های ${Jalali.monthTitle(year, month)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Navy)
        if (monthShifts.isEmpty()) {
            EmptyState(Icons.Default.List, "برای این ماه شیفتی ثبت نشده", "برنامه را خودکار بسازید یا دستی ثبت کنید.")
        }
        monthShifts.groupBy { it.day() }.toSortedMap().forEach { (day, list) ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val friday = Jalali.weekdayIndex(year, month, day) == 6
                    Text(
                        "${Jalali.weekdayName(year, month, day)}  ${day.fa()} ${Jalali.monthNames[month - 1]}",
                        fontWeight = FontWeight.Bold,
                        color = if (friday) Danger else Navy
                    )
                    list.forEach { e ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PaleBlue).padding(start = 10.dp, top = 4.dp, bottom = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(e.type, color = Teal, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            Text(
                                listOf(e.first, e.second).filter { it.isNotBlank() }.joinToString("  ،  "),
                                Modifier.weight(1f),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            IconButton(onClick = {
                                editTarget = e
                                dayText = e.day().fa()
                                firstPerson = e.first
                                secondPerson = e.second
                                shiftType = e.type
                            }) { Icon(Icons.Default.Edit, contentDescription = "ویرایش", tint = Blue, modifier = Modifier.size(20.dp)) }
                            IconButton(onClick = { toDelete = e }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Danger, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    preview?.let { result ->
        SchedulePreviewDialog(
            result = result,
            existingCount = monthShifts.size,
            onSave = {
                store.replaceMonth(year, month, result.entries)
                preview = null
                context.toast("برنامه ماه ذخیره شد")
            },
            onRegenerate = { generate(System.nanoTime()) },
            onDismiss = { preview = null }
        )
    }

    toDelete?.let { e ->
        ConfirmDialog(
            title = "حذف شیفت",
            message = "شیفت ${e.type} روز ${e.day().fa()} حذف شود؟",
            confirmText = "حذف",
            onConfirm = {
                store.shifts.remove(e)
                store.saveShifts()
                toDelete = null
            },
            onDismiss = { toDelete = null }
        )
    }
}

@Composable
private fun RuleRow(name: String, kind: String, days: Set<Int>, color: Color, onRemove: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.10f)).padding(start = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
            Text("$name  •  $kind", fontWeight = FontWeight.Bold, color = color, style = MaterialTheme.typography.bodyMedium)
            Text(days.sorted().joinToString("، ") { it.fa() }, style = MaterialTheme.typography.bodySmall, color = Muted)
        }
        IconButton(onClick = onRemove) { Icon(Icons.Default.Close, contentDescription = "حذف", tint = color) }
    }
}

@Composable
private fun DayGrid(days: Int, selected: Set<Int>, onToggle: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        (1..days).toList().chunked(7).forEach { rowDays ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                rowDays.forEach { d ->
                    val on = d in selected
                    Box(
                        Modifier
                            .weight(1f)
                            .heightIn(min = 38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (on) Navy else PaleBlue)
                            .clickable { onToggle(d) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(d.fa(), color = if (on) Color.White else Navy, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                repeat(7 - rowDays.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun MonthlyShiftCalendar(
    year: Int,
    month: Int,
    shifts: List<ShiftEntry>,
    today: IntArray,
    onSelectDay: (Int) -> Unit
) {
    val maxDay = Jalali.monthLength(year, month)
    val firstWeekday = Jalali.weekdayIndex(year, month, 1)
    val byDay = shifts.groupBy { it.day() }
    val totalCells = ((firstWeekday + maxDay + 6) / 7) * 7

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Jalali.weekdayShort.forEachIndexed { i, n ->
                Box(Modifier.weight(1f).padding(2.dp), contentAlignment = Alignment.Center) {
                    Text(n, color = if (i == 6) Danger else Navy, fontWeight = FontWeight.Bold)
                }
            }
        }
        for (row in 0 until totalCells / 7) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0..6) {
                    val day = row * 7 + col - firstWeekday + 1
                    Box(Modifier.weight(1f).padding(2.dp).heightIn(min = 70.dp)) {
                        if (day in 1..maxDay) {
                            val list = byDay[day].orEmpty()
                            val isToday = today[0] == year && today[1] == month && today[2] == day
                            Card(
                                onClick = { onSelectDay(day) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = when {
                                        isToday -> Color(0xFFD6ECFF)
                                        list.isNotEmpty() -> Color(0xFFDDF4E8)
                                        else -> PaleBlue
                                    }
                                )
                            ) {
                                Column(Modifier.fillMaxWidth().padding(3.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                    Text(
                                        day.fa(),
                                        color = if (col == 6) Danger else Navy,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    list.take(2).forEach { s ->
                                        listOf(s.first, s.second).filter { it.isNotBlank() }.forEach { n ->
                                            Text(
                                                n.trim().substringBefore(" "),
                                                fontSize = 9.sp,
                                                color = if (s.type == TYPE_NIGHT) Blue else Navy,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    if (list.size > 2) Text("+${(list.size - 2).fa()}", fontSize = 9.sp, color = Muted)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonDropdown(label: String, people: List<String>, selected: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            placeholder = { Text("انتخاب از فهرست پرسنل") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().menuAnchor()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            people.forEach { p ->
                DropdownMenuItem(text = { Text(p) }, onClick = { onSelected(p); expanded = false })
            }
        }
    }
}
