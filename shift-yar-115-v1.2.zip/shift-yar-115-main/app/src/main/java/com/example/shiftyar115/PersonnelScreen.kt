package com.example.shiftyar115

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

@Composable
fun PersonnelScreen(store: ShiftStore, context: Context) {
    val t = remember { Jalali.today() }
    var name by rememberSaveable { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<String?>(null) }
    val absent = Rules.parse(store.unavailableRules)
    val must = Rules.parse(store.requiredRules)

    fun submit() {
        val error = store.addPerson(name)
        if (error != null) context.toast(error) else name = ""
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionCard("افزودن پرسنل", icon = Icons.Default.Person) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("نام و نام خانوادگی") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() })
            )
            AppButton("افزودن به فهرست", icon = Icons.Default.Add) { submit() }
        }

        Text(
            "فهرست پرسنل (${store.personnel.size.fa()} نفر)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Navy
        )

        if (store.personnel.isEmpty()) {
            EmptyState(Icons.Default.Person, "هنوز کسی ثبت نشده", "نام اولین نفر را بالا وارد کنید.")
        }

        store.personnel.toList().forEach { person ->
            val monthShifts = store.monthEntries(t[0], t[1]).count { it.first == person || it.second == person }
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Avatar(person)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(person, fontWeight = FontWeight.Bold, color = Navy)
                        val extra = buildList {
                            add("${monthShifts.fa()} شیفت در این ماه")
                            absent.entries.firstOrNull { it.key.equals(person, true) }?.let { add("عدم حضور ${it.value.size.fa()} روز") }
                            must.entries.firstOrNull { it.key.equals(person, true) }?.let { add("حضور اجباری ${it.value.size.fa()} روز") }
                        }
                        Text(extra.joinToString("  •  "), style = MaterialTheme.typography.bodySmall, color = Muted)
                    }
                    IconButton(onClick = { toDelete = person }) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Danger)
                    }
                }
            }
        }
    }

    toDelete?.let { person ->
        ConfirmDialog(
            title = "حذف از فهرست",
            message = "«$person» و قوانین مربوط به او حذف می‌شود. شیفت‌های ثبت‌شده قبلی باقی می‌مانند.",
            confirmText = "حذف",
            onConfirm = {
                store.removePerson(person)
                toDelete = null
                context.toast("نام از فهرست حذف شد")
            },
            onDismiss = { toDelete = null }
        )
    }
}
