package com.example.shiftyar115

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

fun exportMonthlyPdf(
    context: Context,
    shifts: List<ShiftEntry>,
    year: Int,
    month: Int,
    baseName: String
) {
    val filtered = shifts.filter { it.isIn(year, month) }.sortedBy { it.day() }
    if (filtered.isEmpty()) {
        Toast.makeText(context, "برای این ماه شیفتی ثبت نشده است", Toast.LENGTH_LONG).show()
        return
    }

    fun esc(value: String) = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    val only24 = filtered.all { it.type == TYPE_24 }
    val byDay = filtered.groupBy { it.day() }
    val palette = listOf("#DCEBFF", "#DDF5E8", "#FFE8D6", "#F0E2FF", "#FFF2B8", "#D9F4F4", "#FFDDE5", "#E8E8E8")
    val people = filtered.flatMap { listOf(it.first, it.second) }.filter { it.isNotBlank() }.distinct().sorted()
    val personClass = people.mapIndexed { i, n -> n to "person${i % palette.size}" }.toMap()
    val personCss = palette.indices.joinToString("\n") { ".person$it { background:${palette[it]}; font-weight:bold; }" }

    fun personCell(name: String?): String {
        if (name.isNullOrBlank()) return "<td></td>"
        return "<td class=\"${personClass[name] ?: ""} name\">${esc(name)}</td>"
    }

    val days = Jalali.monthLength(year, month)
    val mm = month.toString().padStart(2, '0')
    val rows = (1..days).joinToString("") { day ->
        val de = byDay[day].orEmpty()
        val morning = de.firstOrNull { it.type == TYPE_MORNING } ?: de.firstOrNull { it.type == TYPE_24 }
        val night = de.firstOrNull { it.type == TYPE_NIGHT } ?: de.firstOrNull { it.type == TYPE_24 }
        val weekday = Jalali.weekdayName(year, month, day)
        val cls = if (weekday == "جمعه") "friday" else if (day % 2 == 0) "even" else ""
        val cells = if (only24) {
            personCell(morning?.first) + personCell(morning?.second)
        } else {
            personCell(morning?.first) + personCell(morning?.second) +
                personCell(night?.first) + personCell(night?.second)
        }
        "<tr class=\"$cls\"><td class=\"date\">${"$day/$mm".faDigits()}</td><td class=\"weekday\">${esc(weekday)}</td>$cells</tr>"
    }

    val header = if (only24) {
        """<tr><th rowspan="2" class="date">تاریخ</th><th rowspan="2" class="weekday">روز هفته</th>
           <th colspan="2" class="group">شیفت ۲۴ ساعته</th></tr>
           <tr><th>نفر اول</th><th>نفر دوم</th></tr>"""
    } else {
        """<tr><th rowspan="2" class="date">تاریخ</th><th rowspan="2" class="weekday">روز هفته</th>
           <th colspan="2" class="group">شیفت صبح</th><th colspan="2" class="group">شیفت شب</th></tr>
           <tr><th>نفر اول</th><th>نفر دوم</th><th>نفر اول</th><th>نفر دوم</th></tr>"""
    }

    val tableWidth = if (only24) "50%" else "60%"
    val html = """
        <!doctype html>
        <html lang="fa" dir="rtl">
        <head><meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
        @page { size: A4 portrait; margin: 7mm; }
        * { box-sizing: border-box; }
        body { font-family: sans-serif; direction: rtl; color:#111; margin:0; }
        h1 { text-align:right; width:$tableWidth; margin-right:0; margin-left:auto; font-size:13px; margin-bottom:5px; color:#111; }
        .sub { text-align:right; width:$tableWidth; margin-right:0; margin-left:auto; font-weight:bold; font-size:10px; margin-bottom:7px; }
        table { width:$tableWidth; margin-right:0; margin-left:auto; border-collapse:collapse; table-layout:fixed; }
        th, td { border:1px solid #555; text-align:center; vertical-align:middle; overflow-wrap:anywhere; }
        th { padding:4px 1px; font-size:9px; background:#f0f3f6; }
        td { padding:3px 1px; height:20px; font-size:8px; }
        .group { background:#dce8f5; font-size:10px; font-weight:bold; }
        .date { width:12%; font-weight:bold; }
        .weekday { width:18%; }
        .friday td { color:#b00020; font-weight:bold; }
        tr.even td { background:#edf5fb; }
        .name { font-weight:bold; }
        $personCss
        </style></head>
        <body>
        <h1>برنامه شیفت ماهانه پایگاه ${esc(baseName.ifBlank { "ثبت نشده" })}</h1>
        <div class="sub">اورژانس پیش‌بیمارستانی ۱۱۵ | برنامهٔ ماه ${esc(Jalali.monthTitle(year, month))}</div>
        <table><thead>$header</thead><tbody>$rows</tbody></table>
        </body></html>
    """.trimIndent()

    printHtml(context, html, "ShiftYar-$year-$mm", "گزارش شیفت‌یار ${year.fa()}/${mm.faDigits()}", false)
}

fun printHtml(context: Context, html: String, docName: String, jobTitle: String, landscape: Boolean) {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
    if (printManager == null) {
        Toast.makeText(context, "امکان ساخت PDF در این دستگاه در دسترس نیست", Toast.LENGTH_LONG).show()
        return
    }
    val webView = WebView(context)
    // نگه داشتن مرجع تا WebView قبل از پایان چاپ جمع‌آوری نشود
    (context as? MainActivity)?.printWebView = webView
    webView.settings.defaultTextEncodingName = "UTF-8"
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String?) {
            val adapter = view.createPrintDocumentAdapter(docName)
            val size = if (landscape) PrintAttributes.MediaSize.ISO_A4.asLandscape() else PrintAttributes.MediaSize.ISO_A4
            printManager.print(
                jobTitle,
                adapter,
                PrintAttributes.Builder()
                    .setMediaSize(size)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()
            )
        }
    }
    webView.loadDataWithBaseURL(null, html, "text/HTML", "UTF-8", null)
}

fun exportWorkReportPdf(
    context: Context,
    rows: List<PersonWork>,
    subs: List<Substitution>,
    holidays: Set<Int>,
    year: Int,
    month: Int,
    baseName: String,
    has12: Boolean,
    has24: Boolean
) {
    val active = rows.filter { it.totalShifts > 0 || it.coveredForOthers > 0 || it.coveredByOthers > 0 }
    if (active.isEmpty()) {
        Toast.makeText(context, "برای این ماه کارکردی ثبت نشده است", Toast.LENGTH_LONG).show()
        return
    }
    fun esc(v: String) = v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    val heads = ArrayList<String>()
    heads.add("ردیف"); heads.add("نام و نام خانوادگی")
    if (has12) { heads.add("صبح عادی"); heads.add("صبح تعطیل"); heads.add("شب عادی"); heads.add("شب تعطیل") }
    if (has24) { heads.add("۲۴ ساعته عادی"); heads.add("۲۴ ساعته تعطیل") }
    heads.add("ساعت برنامه"); heads.add("جایگزین دیگران (ساعت)"); heads.add("جایگزین‌شده توسط دیگران (ساعت)"); heads.add("جمع کارکرد (ساعت)")

    val body = active.mapIndexed { i, r ->
        val cells = ArrayList<String>()
        cells.add((i + 1).fa()); cells.add(esc(r.name))
        if (has12) {
            cells.add(r.morningNormal.fa()); cells.add(r.morningHoliday.fa())
            cells.add(r.nightNormal.fa()); cells.add(r.nightHoliday.fa())
        }
        if (has24) { cells.add(r.full24Normal.fa()); cells.add(r.full24Holiday.fa()) }
        cells.add(r.scheduledHours.faHours()); cells.add(r.coveredForOthers.faHours())
        cells.add(r.coveredByOthers.faHours()); cells.add(r.netHours.faHours())
        val cls = if (i % 2 == 1) "even" else ""
        "<tr class=\"$cls\">" + cells.mapIndexed { ci, c -> if (ci == 1) "<td class=\"nm\">$c</td>" else "<td>$c</td>" }.joinToString("") + "</tr>"
    }.joinToString("")

    val monthSubs = subs.filter { it.isIn(year, month) }.sortedBy { it.day() }
    val subsHtml = if (monthSubs.isEmpty()) "" else {
        val r = monthSubs.joinToString("") {
            "<tr><td>${it.day().fa()}</td><td class=\"nm\">${esc(it.substitute)}</td><td class=\"nm\">${esc(it.original)}</td><td>${it.hours.faHours()}</td></tr>"
        }
        "<h2>جزئیات جایگزینی‌ها</h2><table class=\"small\"><thead><tr><th>روز</th><th>جایگزین</th><th>جای چه کسی</th><th>ساعت</th></tr></thead><tbody>$r</tbody></table>"
    }
    val holText = holidays.sorted().joinToString("، ") { it.fa() }

    val html = """
        <!doctype html>
        <html lang="fa" dir="rtl">
        <head><meta charset="UTF-8">
        <style>
        * { box-sizing: border-box; }
        body { font-family: sans-serif; direction: rtl; color:#111; margin:8mm; }
        h1 { font-size:15px; margin:0 0 4px 0; }
        h2 { font-size:12px; margin:14px 0 4px 0; }
        .sub { font-size:10px; font-weight:bold; margin-bottom:4px; }
        .note { font-size:9px; color:#333; margin-bottom:8px; }
        table { width:100%; border-collapse:collapse; table-layout:auto; }
        table.small { width:55%; }
        th, td { border:1px solid #555; text-align:center; padding:4px 3px; font-size:10px; }
        th { background:#dce8f5; font-size:9px; }
        td.nm { text-align:right; font-weight:bold; }
        tr.even td { background:#edf5fb; }
        </style></head>
        <body>
        <h1>گزارش کارکرد ماهانه پایگاه ${esc(baseName.ifBlank { "ثبت نشده" })}</h1>
        <div class="sub">اورژانس پیش‌بیمارستانی ۱۱۵ | ${esc(Jalali.monthTitle(year, month))}</div>
        <div class="note">روزهای تعطیل این ماه: $holText &nbsp;|&nbsp; شیفت صبح و شب ۱۲ ساعت و شیفت ۲۴ ساعته ۲۴ ساعت حساب شده است. تعطیل بودن شیفت بر اساس تاریخ شروع آن است.</div>
        <table><thead><tr>${heads.joinToString("") { "<th>$it</th>" }}</tr></thead><tbody>$body</tbody></table>
        $subsHtml
        </body></html>
    """.trimIndent()

    printHtml(context, html, "ShiftYar-Report-$year-$month", "کارکرد شیفت‌یار ${year.fa()}/${month.fa()}", true)
}
