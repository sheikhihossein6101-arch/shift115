package com.example.shiftyar115

import kotlin.random.Random

data class ScheduleResult(
    val entries: List<ShiftEntry>,
    val counts: Map<String, Int>,
    val warnings: List<String>,
    val restViolations: Int,
    val missingSlots: Int
)

/**
 * ساخت خودکار برنامه ماهانه (دو نفر در هر شیفت).
 *
 * قواعد سخت: عدم حضور، یک نفر فقط یک بار در روز (در حالت صبح/شب).
 * قواعد نرم به ترتیب اولویت: حضور اجباری، حداقل استراحت بین شیفت‌ها، عدالت در تعداد شیفت.
 * چند بار با ترتیب تصادفی متفاوت ساخته می‌شود و بهترین نتیجه انتخاب می‌شود.
 */
object ShiftScheduler {
    private const val NEVER = -1_000_000

    private class Attempt(
        val entries: List<ShiftEntry>,
        val counts: Map<String, Int>,
        val warnings: List<String>,
        val restViolations: Int,
        val missing: Int,
        val spread: Int
    ) {
        fun betterThan(o: Attempt): Boolean {
            if (missing != o.missing) return missing < o.missing
            if (restViolations != o.restViolations) return restViolations < o.restViolations
            return spread < o.spread
        }
    }

    fun build(
        personnel: List<String>,
        year: Int,
        month: Int,
        twoTypes: Boolean,
        unavailableRaw: String,
        requiredRaw: String,
        restSlots: Int,
        seed: Long,
        attempts: Int = 150
    ): ScheduleResult {
        val days = Jalali.monthLength(year, month)
        val unavailable = resolve(Rules.parse(unavailableRaw), personnel, days)
        val required = resolve(Rules.parse(requiredRaw), personnel, days)
        val master = Random(seed)
        var best: Attempt? = null
        for (i in 0 until maxOf(1, attempts)) {
            val a = buildOnce(personnel, year, month, days, twoTypes, unavailable, required, restSlots, Random(master.nextLong()))
            val b = best
            if (b == null || a.betterThan(b)) best = a
        }
        val r = best!!
        val warnings = ArrayList<String>()
        val unknown = (Rules.parse(unavailableRaw).keys + Rules.parse(requiredRaw).keys)
            .filter { n -> personnel.none { it.equals(n, ignoreCase = true) } }
            .distinct()
        unknown.forEach { warnings.add("«$it» در فهرست پرسنل نیست و قوانینش نادیده گرفته شد") }
        warnings.addAll(r.warnings)
        if (r.restViolations > 0) {
            warnings.add("در ${r.restViolations.fa()} مورد حداقل استراحت رعایت نشد (تعداد پرسنل کافی نیست)")
        }
        return ScheduleResult(r.entries, r.counts, warnings, r.restViolations, r.missing)
    }

    private fun resolve(
        rules: Map<String, Set<Int>>,
        personnel: List<String>,
        days: Int
    ): Map<String, Set<Int>> {
        val out = HashMap<String, Set<Int>>()
        rules.forEach { (name, ds) ->
            val p = personnel.firstOrNull { it.equals(name, ignoreCase = true) }
            if (p != null) out[p] = ds.filter { it in 1..days }.toSet()
        }
        return out
    }

    private fun buildOnce(
        personnel: List<String>,
        year: Int,
        month: Int,
        days: Int,
        twoTypes: Boolean,
        unavailable: Map<String, Set<Int>>,
        required: Map<String, Set<Int>>,
        rest: Int,
        rng: Random
    ): Attempt {
        val typeNames = if (twoTypes) listOf(TYPE_MORNING, TYPE_NIGHT) else listOf(TYPE_24)
        val tie = personnel.associateWith { rng.nextDouble() }
        val availSlots = personnel.associateWith { p ->
            maxOf(1, (days - (unavailable[p]?.size ?: 0)) * typeNames.size)
        }
        val count = personnel.associateWith { 0 }.toMutableMap()
        val last = personnel.associateWith { NEVER }.toMutableMap()
        val entries = ArrayList<ShiftEntry>()
        val warnings = ArrayList<String>()
        var restViolations = 0
        var missing = 0

        for (day in 1..days) {
            val blocked = personnel.filter { day in (unavailable[it] ?: emptySet()) }.toSet()
            val assigned = HashSet<String>()
            val pending = personnel
                .filter { day in (required[it] ?: emptySet()) && it !in blocked }
                .toMutableList()
            personnel
                .filter { day in (required[it] ?: emptySet()) && it in blocked }
                .forEach { warnings.add("روز ${day.fa()}: «$it» هم حضور اجباری و هم عدم حضور دارد") }

            for (t in typeNames.indices) {
                val slot = (day - 1) * typeNames.size + t
                val chosen = ArrayList<String>()
                while (chosen.size < 2 && pending.isNotEmpty()) chosen.add(pending.removeAt(0))

                fun restOk(p: String): Boolean = slot - last.getValue(p) - 1 >= rest

                if (chosen.size < 2) {
                    val strict = personnel
                        .filter { it !in blocked && it !in assigned && it !in chosen && restOk(it) }
                        .sortedWith(
                            compareBy<String> { count.getValue(it).toDouble() / availSlots.getValue(it) }
                                .thenByDescending { slot - last.getValue(it) }
                                .thenBy { tie.getValue(it) }
                        )
                    for (p in strict) {
                        if (chosen.size >= 2) break
                        chosen.add(p)
                    }
                }
                if (chosen.size < 2) {
                    val relaxed = personnel
                        .filter { it !in blocked && it !in assigned && it !in chosen }
                        .sortedWith(
                            compareByDescending<String> { slot - last.getValue(it) }
                                .thenBy { count.getValue(it).toDouble() / availSlots.getValue(it) }
                                .thenBy { tie.getValue(it) }
                        )
                    for (p in relaxed) {
                        if (chosen.size >= 2) break
                        chosen.add(p)
                    }
                }

                for (p in chosen) {
                    if (!restOk(p)) restViolations++
                    count[p] = count.getValue(p) + 1
                    last[p] = slot
                    assigned.add(p)
                }

                if (chosen.size < 2) {
                    missing += 2 - chosen.size
                    val what = if (chosen.isEmpty()) "هیچ نیرویی" else "فقط یک نفر"
                    warnings.add("روز ${day.fa()} (${typeNames[t]}): $what در دسترس بود")
                }
                if (chosen.isNotEmpty()) {
                    entries.add(
                        ShiftEntry(
                            Jalali.key(year, month, day),
                            typeNames[t],
                            chosen[0],
                            chosen.getOrElse(1) { "" }
                        )
                    )
                }
            }
        }

        val active = personnel.filter { days - (unavailable[it]?.size ?: 0) > 0 }
        val spread = if (active.isEmpty()) 0
        else active.maxOf { count.getValue(it) } - active.minOf { count.getValue(it) }
        return Attempt(entries, count.toMap(), warnings, restViolations, missing, spread)
    }
}
