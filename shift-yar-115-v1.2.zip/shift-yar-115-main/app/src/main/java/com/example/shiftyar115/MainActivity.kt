package com.example.shiftyar115

import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Page(val title: String, val label: String, val icon: ImageVector) {
    HOME("خانه", "خانه", Icons.Default.Home),
    SHIFTS("مدیریت شیفت‌ها", "شیفت‌ها", Icons.Default.DateRange),
    PERSONNEL("مدیریت پرسنل", "پرسنل", Icons.Default.Person),
    REPORT("کارکرد ماهانه", "کارکرد", Icons.Default.List)
}

class MainActivity : ComponentActivity() {
    /** نگهداری WebView چاپ تا پایان ساخت PDF */
    var printWebView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShiftYarTheme {
                ShiftYarRoot()
            }
        }
    }
}

@Composable
fun ShiftYarRoot() {
    var splash by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1800)
        splash = false
    }
    if (splash) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Navy)
                .clickable { splash = false }
        ) {
            Image(
                painter = painterResource(R.drawable.shiftyar),
                contentDescription = "شیفت‌یار ۱۱۵",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    } else {
        ShiftYarApp()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShiftYarApp() {
    val context = LocalContext.current
    val store = remember { ShiftStore(context) }
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    var pageName by rememberSaveable { mutableStateOf(Page.HOME.name) }
    val page = Page.valueOf(pageName)
    var showContact by remember { mutableStateOf(false) }
    var showExit by remember { mutableStateOf(false) }
    var showBackup by remember { mutableStateOf(false) }
    var pendingImport by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(store.exportJson().toByteArray(Charsets.UTF_8))
                }
                context.toast("فایل پشتیبان ذخیره شد")
            } catch (_: Exception) {
                context.toast("ذخیره فایل پشتیبان انجام نشد", true)
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                }
                if (text.isNullOrBlank()) context.toast("فایل خالی است", true) else pendingImport = text
            } catch (_: Exception) {
                context.toast("خواندن فایل انجام نشد", true)
            }
        }
    }

    fun navigate(target: Page) {
        pageName = target.name
        scope.launch { drawerState.close() }
    }

    BackHandler(enabled = drawerState.isOpen || page != Page.HOME) {
        if (drawerState.isOpen) scope.launch { drawerState.close() } else pageName = Page.HOME.name
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    HeroCard(Modifier.padding(12.dp)) {
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) { Text("✚", color = Color.White, style = MaterialTheme.typography.headlineSmall) }
                        Text("شیفت‌یار ۱۱۵", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(
                            if (store.baseName.isBlank()) "اورژانس پیش‌بیمارستانی" else "پایگاه ${store.baseName}",
                            color = Color(0xFFD8E8FA),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Page.values().forEach { p ->
                        DrawerItem(p.title, p.icon, page == p) { navigate(p) }
                    }
                    DrawerItem("پشتیبان‌گیری و بازیابی", Icons.Default.Share, false) {
                        scope.launch { drawerState.close() }
                        showBackup = true
                    }
                    DrawerItem("تماس با ما", Icons.Default.Call, false) {
                        scope.launch { drawerState.close() }
                        showContact = true
                    }
                    DrawerItem("خروج", Icons.Default.Close, false) {
                        scope.launch { drawerState.close() }
                        showExit = true
                    }
                }
            }
        }
    ) {
        Scaffold(
            containerColor = PageBg,
            topBar = {
                TopAppBar(
                    title = { Text(page.title, fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "منو")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Navy,
                        titleContentColor = Color.White,
                        navigationIconContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    Page.values().forEach { p ->
                        NavigationBarItem(
                            selected = page == p,
                            onClick = { pageName = p.name },
                            icon = { Icon(p.icon, contentDescription = null) },
                            label = { Text(p.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Navy,
                                indicatorColor = Navy,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Crossfade(targetState = page, label = "page") { current ->
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (current) {
                        Page.HOME -> HomeScreen(store, context) { navigate(it) }
                        Page.SHIFTS -> ShiftsScreen(store, context)
                        Page.PERSONNEL -> PersonnelScreen(store, context)
                        Page.REPORT -> ReportScreen(store, context)
                    }
                }
            }
        }
    }

    if (showContact) ContactDialog(context) { showContact = false }

    if (showExit) {
        ConfirmDialog(
            title = "خروج از برنامه",
            message = "آیا می‌خواهید از برنامه خارج شوید؟",
            confirmText = "بله، خروج",
            onConfirm = { showExit = false; (context as? ComponentActivity)?.finish() },
            onDismiss = { showExit = false }
        )
    }

    if (showBackup) {
        BackupDialog(
            onExport = {
                showBackup = false
                val t = Jalali.today()
                exportLauncher.launch("shiftyar-backup-${t[0]}-${t[1].toString().padStart(2, '0')}-${t[2].toString().padStart(2, '0')}.json")
            },
            onImport = {
                showBackup = false
                importLauncher.launch(arrayOf("*/*"))
            },
            onDismiss = { showBackup = false }
        )
    }

    pendingImport?.let { raw ->
        ConfirmDialog(
            title = "بازیابی اطلاعات",
            message = "اطلاعات فعلی (پرسنل، برنامه‌ها و قوانین) با محتوای فایل جایگزین می‌شود. ادامه می‌دهید؟",
            confirmText = "جایگزین کن",
            onConfirm = {
                val error = store.importJson(raw)
                pendingImport = null
                if (error == null) context.toast("اطلاعات بازیابی شد") else context.toast(error, true)
            },
            onDismiss = { pendingImport = null }
        )
    }
}

@Composable
private fun DrawerItem(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(label, fontWeight = FontWeight.Medium) },
        icon = { Icon(icon, contentDescription = null) },
        selected = selected,
        onClick = onClick,
        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = Navy,
            selectedTextColor = Color.White,
            selectedIconColor = Color.White,
            unselectedIconColor = Blue,
            unselectedTextColor = Navy
        )
    )
}
