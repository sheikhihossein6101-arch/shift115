package com.example.shiftyar115

import java.time.LocalDate
import java.util.Locale

const val TYPE_24 = "۲۴ ساعته"
const val TYPE_MORNING = "صبح"
const val TYPE_NIGHT = "شب"

object Jalali {
    val monthNames = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )
    val weekdayNames = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
    val weekdayShort = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

    fun toGregorian(jy: Int, jm: Int, jd: Int): IntArray {
        val year = jy + 1595
        var days = -355668 + 365 * year + (year / 33) * 8 + ((year % 33 + 3) / 4) + jd
        days += if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days -= 1
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days += 1
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val leap = gy % 4 == 0 && (gy % 100 != 0 || gy % 400 == 0)
        val monthDays = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 1
        while (gm <= 12 && gd > monthDays[gm]) {
            gd -= monthDays[gm]
            gm++
        }
        return intArrayOf(gy, gm, gd)
    }

    fun toJalali(gy: Int, gm: Int, gd: Int): IntArray {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return intArrayOf(jy, jm, jd)
    }

    fun today(): IntArray {
        val d = LocalDate.now()
        return toJalali(d.year, d.monthValue, d.dayOfMonth)
    }

    private fun epochDay(jy: Int, jm: Int, jd: Int): Long {
        val g = toGregorian(jy, jm, jd)
        return LocalDate.of(g[0], g[1], g[2]).toEpochDay()
    }

    fun isLeap(year: Int): Boolean = epochDay(year + 1, 1, 1) - epochDay(year, 1, 1) == 366L

    fun monthLength(year: Int, month: Int): Int = when {
        month <= 6 -> 31
        month <= 11 -> 30
        else -> if (isLeap(year)) 30 else 29
    }

    /** 0 = شنبه ... 6 = جمعه */
    fun weekdayIndex(jy: Int, jm: Int, jd: Int): Int {
        val g = toGregorian(jy, jm, jd)
        val dow = LocalDate.of(g[0], g[1], g[2]).dayOfWeek.value // Mon=1..Sun=7
        return (dow + 1) % 7
    }

    fun weekdayName(jy: Int, jm: Int, jd: Int): String = weekdayNames[weekdayIndex(jy, jm, jd)]

    fun key(y: Int, m: Int, d: Int): String = String.format(Locale.US, "%04d/%02d/%02d", y, m, d)

    fun monthTitle(year: Int, month: Int): String =
        monthNames[(month - 1).coerceIn(0, 11)] + " " + year.fa()
}

fun String.faDigits(): String =
    map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

fun String.enDigits(): String = map {
    when (it) {
        in '۰'..'۹' -> '0' + (it - '۰')
        in '٠'..'٩' -> '0' + (it - '٠')
        else -> it
    }
}.joinToString("")

fun Int.fa(): String = toString().faDigits()
