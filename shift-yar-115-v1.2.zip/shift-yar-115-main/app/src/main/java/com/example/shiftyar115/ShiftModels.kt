package com.example.shiftyar115

data class ShiftEntry(
    val date: String,
    val type: String,
    val first: String,
    val second: String
)

fun ShiftEntry.parts(): IntArray? {
    val p = date.enDigits().split("/")
    if (p.size != 3) return null
    val y = p[0].toIntOrNull()
    val m = p[1].toIntOrNull()
    val d = p[2].toIntOrNull()
    return if (y == null || m == null || d == null) null else intArrayOf(y, m, d)
}

fun ShiftEntry.isIn(year: Int, month: Int): Boolean {
    val p = parts() ?: return false
    return p[0] == year && p[1] == month
}

fun ShiftEntry.day(): Int = parts()?.get(2) ?: 0

fun ShiftEntry.weekday(): String {
    val p = parts() ?: return ""
    return Jalali.weekdayName(p[0], p[1], p[2])
}

/** قوانین ذخیره‌شده به صورت خطوط «نام:روز،روز،...» (سازگار با نسخه‌های قبل). */
object Rules {
    fun parse(raw: String): Map<String, Set<Int>> {
        val out = LinkedHashMap<String, Set<Int>>()
        raw.lines().forEach { line ->
            val parts = line.split(":", limit = 2)
            if (parts.size == 2) {
                val name = parts[0].trim()
                val days = parts[1].enDigits().split(",", "،", " ")
                    .mapNotNull { it.trim().toIntOrNull() }
                    .toSet()
                if (name.isNotBlank() && days.isNotEmpty()) out[name] = days
            }
        }
        return out
    }

    fun format(map: Map<String, Set<Int>>): String =
        map.entries.joinToString("\n") { e -> e.key + ":" + e.value.sorted().joinToString(",") }

    fun upsert(raw: String, name: String, days: Set<Int>): String {
        val m = LinkedHashMap(parse(raw))
        m.keys.removeAll { it.equals(name, ignoreCase = true) }
        if (days.isNotEmpty()) m[name] = days
        return format(m)
    }

    fun remove(raw: String, name: String): String = upsert(raw, name, emptySet())
}
